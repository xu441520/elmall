 export default {
    count:9,
    count2:88,
    count3:33,
    str:"hello world",
    arr:["9.9元","6.8元","88元","23元"],
    todos:[
      {id:1,text:"子涵",vip:true},
      {id:2,text:"紹冲",vip:false},
      {id:3,text:"欢迎",vip:true},
      {id:4,text:"红康",vip:false},
      {id:5,text:"赵鑫",vip:true}
    ]
  }