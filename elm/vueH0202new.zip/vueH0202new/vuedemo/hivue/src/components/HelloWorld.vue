<template>
  <div class="one">
      <ul>
        <li>NBA1</li>
        <li>NBA1</li>
        <li>NBA1</li>
        <li>NBA1</li>
        </ul>  
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.one {
  border:3px solid red;
}
</style>
